#!/usr/bin/env python
# coding: utf-8

# # Môn học: Giới thiệu về Khoa học Dữ liệu – DSP301x
# 
# ## Assignment số: 02
# 
# ### Tên dự án: Tính toán và phân tích điểm thi (Test Grade Calculator)
# #### Sử dụng thư viện Pandas và Numpy trong code Python.

# In[1]:


import pandas as pd
import numpy as np
import statistics
import os

'''
    Nhập vào tên file, kiểm tra sự tồn tại của file và in thông báo.
    Sử dụng try/except để bắt lỗi.
'''
def read_file():
    while True:
        filename = input("Enter a class file to grade (i.e: class1 for class1.txt): ")
        try:
            with open(filename + '.txt', 'r') as file:
                print("Successfully opened " + filename + ".txt")
                return file.readlines(), filename
        except FileNotFoundError:
            print("File cannot be found.")

def analyze_data(lines):
    print("**** ANALYZING ****")
    valid_lines = 0
    invalid_lines = 0
    for line in lines:
        data = line.strip().split(',')
        # Kiểm tra nếu tính hợp lệ của dữ liệu!
        
        if len(data) != 26:
            print("Invalid line of data: does not contain exactly 26 values: ")
            print(line)
            invalid_lines += 1
        elif not data[0].startswith('N') or not data[0][1:].isdigit() or len(data[0]) != 9:
            print("Invalid line of data: N# is invalid: ")
            print(line)
            invalid_lines += 1         
        else:
            valid_lines += 1
    if invalid_lines == 0:
        print('No errors founds! \n')
    print("**** REPORT ****")
    print("Total valid lines of data: ", valid_lines)
    print("Total invalid lines of data: ", invalid_lines)
    print("************************")
    
def grade_data(lines, filename):
    answer_key = "B,A,D,D,C,B,D,A,C,C,D,B,A,B,A,C,B,D,A,C,A,A,B,D,D"
    #answers = list(answer_key.split(','))
    
    answers = list(answer_key.replace(',', ''))
    with open(filename + '.txt', 'r') as file:
        lines = file.readlines()
    
    # Tạo mảng lưu điểm và ID
    scores = []
    ids = []
    # Tạo mảng lưu các câu hỏi bị bỏ qua và trả lời sai.
    skipped = [0]*25
    incorrect = [0]*25
    for line in lines:
        data = line.strip().split(',')
    
        if len(data) == 26 and data[0].startswith('N') and data[0][1:].isdigit() and len(data[0]) == 9:
            score = 0
            for i in range(25):
                if data[i+1] == '':
                    skipped[i] += 1
                elif data[i+1] == answers[i]:
                    score += 4
                else:
                    score -= 1
                    incorrect[i] += 1
            scores.append(score)
            ids.append(data[0])
                
    scores = np.array(scores)
    print("Total student of high scores (>80): ", np.sum(scores > 80))
    print("Mean (average) score: ", round(np.mean(scores), 3))
    print("Highest score: ", np.max(scores))
    print("Lowest score: ", np.min(scores))
    print("Range of scores: ", np.ptp(scores))  # print("Range of scores: ", np.max(scores) - np.min(scores))
    print("Median score: ", np.median(scores))
    print("*************************")
    skipped = [(i+1, skipped[i], round(skipped[i]/len(scores), 3)) for i in range(25)]
    skipped.sort(key=lambda x: x[1], reverse=True)
    print("Question that most people skip: ", ', '.join(f"{i} - {count} - {rate}" for i, count, rate in skipped if count == skipped[0][1]))
    print("*************************")
    
    incorrect = [(i+1, incorrect[i], round(incorrect[i]/len(scores), 3)) for i in range(25)]
    incorrect.sort(key=lambda x: x[1], reverse=True)
    print("Question that most people answer incorrectly: ", ', '.join(f"{i} - {count} - {rate}" for i, count, rate in incorrect if count == incorrect[0][1]))


    # Tạo tệp kết quả lưu 2 trường ID và Tổng số điểm của sinh viên.
    # File kết quả được lưu tại thư mục ./Data Files/Output.
    
    with open('./Output/' + filename + '_grades.txt', 'w') as file:
        for id, score in zip(ids, scores):
            file.write(id + ',' + str(score) + '\n')

#==============================================
# Hàm main() chương trình.
def main():
    lines, filename = read_file()
    analyze_data(lines)
    grade_data(lines, filename)
    
if __name__ == "__main__":
    main()


# In[2]:


main()


# In[ ]:





# Môn học: Giới thiệu về Khoa học Dữ liệu – DSP301x

## Assignment số: 02

### Tên dự án: Tính toán và phân tích điểm thi (Test Grade Calculator)

Task 1:
1.1. Tạo một chương trình Python mới có tên “lastname_firstname_grade_the_exams.py.”
1.2. Viết một chương trình cho phép người dùng nhập tên của một tệp và truy cập đọc.
1.3. Nếu tệp tồn tại, bạn có thể in ra một thông báo xác nhận. 
    Nếu tệp không tồn tại, bạn nên cho người dùng biết rằng không thể tìm thấy tệp và nhắc lại họ.
1.4. Sử dụng try/except để thực hiện việc này 

```python
    filename = input("Enter a class file to grade (i.e: class1 for class1.txt): ")
        try:
            with open(filename + '.txt', 'r') as file:
                print("Successfully opened " + filename + ".txt")
                return file.readlines(), filename
        except FileNotFoundError:
            print("File cannot be found.")

```
## Kêt quả:
    Enter a class file to grade (i.e: class1 for class1.txt): foo
    File cannot be found.
    Enter a class file to grade (i.e: class1 for class1.txt): class1
    Successfully opened class1.txt

Task 2:
Tiếp theo,  phân tích dữ liệu có trong tệp vừa mở để đảm bảo rằng nó ở đúng định dạng. 
Mỗi tệp dữ liệu chứa một loạt câu trả lời của học sinh ở định dạng sau:
N12345678,B,A,D,D,C,B,D,A,C,C,D,B,A,B,A,C,B,D,A,C,A,A,B,D,D
hoặc
N12345678,B,,D,,C,B,,A,C,C,,B,A,B,A,,,,A,C,A,A,B,D,
Giá trị đầu tiên là số ID của sinh viên. 25 chữ cái sau là câu trả lời của học sinh cho kỳ thi. 
Tất cả các giá trị được phân tách bằng dấu phẩy. 
Nếu không có chữ cái nào sau dấu phẩy, điều này có nghĩa là học sinh đã bỏ qua việc trả lời câu hỏi.
Nhiệm vụ cho phần này của chương trình là thực hiện như sau:
2.1. Báo cáo tổng số dòng dữ liệu được lưu trữ trong tệp.
2.2. Báo cáo tổng số dòng dữ liệu không hợp lệ trong tệp.
	Một dòng hợp lệ chứa danh sách 26 giá trị được phân tách bằng dấu phẩy
	N# cho một học sinh là mục đầu tiên trên dòng. Nó phải chứa ký tự “N” theo sau là 8 ký tự số.
2.3. Nếu một dòng dữ liệu không hợp lệ, bạn nên báo cáo cho người dùng bằng cách in ra một thông báo lỗi. 

```python
    for line in lines:
        data = line.strip().split(',')
        # Kiểm tra nếu tính hợp lệ của dữ liệu!
        
        if len(data) != 26:
            print("Invalid line of data: does not contain exactly 26 values: ")
            print(line)
            invalid_lines += 1
        elif not data[0].startswith('N') or not data[0][1:].isdigit() or len(data[0]) != 9:
            print("Invalid line of data: N# is invalid: ")
            print(line)
            invalid_lines += 1         
        else:
            valid_lines += 1
    if invalid_lines == 0:
        print('No errors founds! \n')
```
## Kết quả:
    Enter a class file to grade (i.e: class1 for class1.txt): foo
    File cannot be found.
    Enter a class file to grade (i.e: class1 for class1.txt): class1
    Successfully opened class1.txt
    **** ANALYZING ****
    No errors founds! 

    **** REPORT ****
    Total valid lines of data:  20
    Total invalid lines of data:  0
    
    Enter a class file to grade (i.e: class1 for class1.txt): class2
    Successfully opened class2.txt
    **** ANALYZING ****
    Invalid line of data: does not contain exactly 26 values: 
    N00000023,,A,D,D,C,B,D,A,C,C,,C,,B,A,C,B,D,A,C,A,A

    Invalid line of data: N# is invalid: 
    N0000002,B,A,D,D,C,B,D,A,C,D,D,D,A,,A,C,D,,A,C,A,A,B,D,D

    Invalid line of data: N# is invalid: 
    NA0000027,B,A,D,D,,B,,A,C,B,D,B,A,,A,C,B,D,A,,A,A,B,D,D

    Invalid line of data: does not contain exactly 26 values: 
    N00000035,B,A,D,D,B,B,,A,C,,D,B,A,B,A,A,B,D,A,C,A,C,B,D,D,A,A

    **** REPORT ****
    Total valid lines of data:  21
    Total invalid lines of data:  4

Task 3:
Chấm điểm các bài thi. Kỳ thi gồm 25 câu hỏi, trắc nghiệm. Đây là một chuỗi đại diện cho các câu trả lời:

answer_key = "B,A,D,D,C,B,D,A,C,C,D,B,A,B,A,C,B,D,A,C,A,A,B,D,D"

Chương trình sử dụng những câu trả lời này để tính điểm cho mỗi dòng dữ liệu hợp lệ. Điểm có thể được tính như sau:
•	+4 điểm cho mỗi câu trả lời đúng
•	0 điểm cho mỗi câu trả lời bị bỏ qua
•	-1 điểm cho mỗi câu trả lời sai
Tính toán các thống kê sau cho từng lớp:
3.1. Đếm số lượng học sinh đạt điểm cao (>80).
3.2. Điểm trung bình.
3.3. Điểm cao nhất.
3.4. Điểm thấp nhất.
3.5. Miền giá trị của điểm (cao nhất trừ thấp nhất).
3.6. Giá trị trung vị (Sắp xếp các điểm theo thứ tự tăng dần. Nếu # học sinh là số lẻ, bạn có thể lấy giá trị nằm ở giữa của tất cả các điểm (tức là [0, 50, 100] — trung vị là 50). Nếu # học sinh là chẵn bạn có thể tính giá trị trung vị bằng cách lấy giá trị trung bình của hai giá trị giữa (tức là [0, 50, 60, 100] — giá trị trung vị là 55)).
3.7. Trả về các câu hỏi bị học sinh bỏ qua nhiều nhất theo thứ tự: số thứ tự câu hỏi - số lượng học sinh bỏ qua -  tỉ lệ bị bỏ qua (nếu có cùng số lượng cho nhiều câu hỏi bị bỏ thì phải liệt kê ra đầy đủ).
3.8. Trả về các câu hỏi bị học sinh sai qua nhiều nhất theo thứ tự: số thứ tự câu hỏi - số lượng học sinh trả lời sai - tỉ lệ bị sai (nếu có cùng số lượng cho nhiều câu hỏi bị sai thì phải liệt kê ra đầy đủ).
Lưu ý: các giá trị số thực làm tròn 3 chữ số thập phân

```python
    answer_key = "B,A,D,D,C,B,D,A,C,C,D,B,A,B,A,C,B,D,A,C,A,A,B,D,D"
    #answers = list(answer_key.split(','))
    
    answers = list(answer_key.replace(',', ''))
    with open(filename + '.txt', 'r') as file:
        lines = file.readlines()
    
    # Tạo mảng lưu điểm và ID
    scores = []
    ids = []
    # Tạo mảng lưu các câu hỏi bị bỏ qua và trả lời sai.
    skipped = [0]*25
    incorrect = [0]*25
    for line in lines:
        data = line.strip().split(',')
    
        if len(data) == 26 and data[0].startswith('N') and data[0][1:].isdigit() and len(data[0]) == 9:
            score = 0
            for i in range(25):
                if data[i+1] == '':
                    skipped[i] += 1
                elif data[i+1] == answers[i]:
                    score += 4
                else:
                    score -= 1
                    incorrect[i] += 1
            scores.append(score)
            ids.append(data[0])
                
    scores = np.array(scores)
```
## Kết quả
    Enter a class file to grade (i.e: class1 for class1.txt): class1
    Successfully opened class1.txt
    **** ANALYZING ****
    No errors founds! 

    **** REPORT ****
    Total valid lines of data:  20
    Total invalid lines of data:  0
    *************************
    Total student of high scores (>80):  6
    Mean (average) score:  75.6
    Highest score:  91
    Lowest score:  59
    Range of scores:  32
    Median score:  73.0
    *************************
    Question that most people skip:  3 - 4 - 0.2, 5 - 4 - 0.2, 23 - 4 - 0.2
    *************************
    Question that most people answer incorrectly:  10 - 4 - 0.2, 14 - 4 - 0.2, 16 - 4 - 0.2, 19 - 4 - 0.2, 22 - 4 - 0.2
    
    Enter a class file to grade (i.e: class1 for class1.txt): class2
    Successfully opened class2.txt
    **** ANALYZING ****
    Invalid line of data: does not contain exactly 26 values: 
    N00000023,,A,D,D,C,B,D,A,C,C,,C,,B,A,C,B,D,A,C,A,A

    Invalid line of data: N# is invalid: 
    N0000002,B,A,D,D,C,B,D,A,C,D,D,D,A,,A,C,D,,A,C,A,A,B,D,D

    Invalid line of data: N# is invalid: 
    NA0000027,B,A,D,D,,B,,A,C,B,D,B,A,,A,C,B,D,A,,A,A,B,D,D

    Invalid line of data: does not contain exactly 26 values: 
    N00000035,B,A,D,D,B,B,,A,C,,D,B,A,B,A,A,B,D,A,C,A,C,B,D,D,A,A

    **** REPORT ****
    Total valid lines of data:  21
    Total invalid lines of data:  4
    *************************
    Total student of high scores (>80):  7
    Mean (average) score:  78.0
    Highest score:  100
    Lowest score:  66
    Range of scores:  34
    Median score:  76.0
    *************************
    Question that most people skip:  22 - 6 - 0.286
    *************************
    Question that most people answer incorrectly:  18 - 5 - 0.238

Task 4:
Tạo một tệp “kết quả” chứa các kết quả chi tiết cho từng học sinh trong lớp. 
Mỗi dòng của tệp này phải chứa số ID của học sinh, dấu phẩy và sau đó là điểm của họ. 
Tên tệp này dựa trên tên tệp gốc được cung cấp 
— ví dụ: nếu người dùng muốn phân tích “class1.txt”, kết quả trong tệp có tên “class1_grades.txt”.

## Tạo tệp kết quả lưu 2 trường ID và Tổng số điểm của sinh viên.
## File kết quả được lưu tại thư mục ./Data Files/Output.

```python

    with open('./Output/' + filename + '_grades.txt', 'w') as file:
        for id, score in zip(ids, scores):
            file.write(id + ',' + str(score) + '\n')

```

## Kết quả

```
    class1_grades.txt
    N00000001,59
    N00000002,70
    N00000003,84
    N00000004,73
    N00000005,83
    N00000006,66
    N00000007,88
    N00000008,67
    N00000009,86
    N00000010,73
    N00000011,86
    N00000012,73
    N00000013,73
    N00000014,78
    N00000015,72
    N00000016,91
    N00000017,66
    N00000018,78
    N00000019,78
    N00000020,68
```

## Tạo hàm main() chương trình.

```python
def main():
    lines, filename = read_file()
    analyze_data(lines)
    grade_data(lines, filename)
    
if __name__ == "__main__":
    main()
```